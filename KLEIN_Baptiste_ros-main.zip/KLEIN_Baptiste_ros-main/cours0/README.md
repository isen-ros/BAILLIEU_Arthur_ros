# Cour 
Tout information, note lie aux exercises de ce cours, devent etre redige dans ce fichier. 
